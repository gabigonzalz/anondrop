# AnonDrop - P2P File Sharing

A secure, peer-to-peer file sharing application built with Hyperdrive and Hyperswarm. Share files directly between peers without any central server.

## Features

- 🔒 Secure peer-to-peer file sharing
- 🚀 No central server required
- 📁 Direct file transfers
- 🔑 Session-based sharing
- 📱 Modern, responsive UI
- 🎨 Dark mode interface
- 📋 Copy-to-clipboard functionality
- 📊 Real-time peer connection status

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/AnonDrop.git
cd AnonDrop
```

2. Install dependencies:
```bash
npm install
```

3. Start the application:
```bash
npm start
```

## Usage

### Creating a Session

1. Click "Create New Session"
2. Wait for the session to initialize
3. Copy the generated session key
4. Share the key with the recipient
5. Click "Select File to Share" to begin sharing files

### Joining a Session

1. Click "Join Existing Session"
2. Paste the session key provided by the sender
3. Click "Join Session"
4. Files will automatically download to your downloads folder

## Technical Details

- Built with Hyperdrive for P2P file storage
- Uses Hyperswarm for peer discovery and connection
- Implements Localdrive for local file system operations
- Secure file transfer with no central server
- Automatic file synchronization

## Security

- All connections are peer-to-peer
- No central server storing your files
- Files are transferred directly between peers
- Session keys are required for connection
- No file data is stored on any server

## Development

### Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

### Project Structure

```
AnonDrop/
├── app.js              # Main application logic
├── index.html          # User interface
├── sender-folder/      # Files to share
├── downloads/          # Received files
├── storage/           # Storage for sender
└── storage-receiver/  # Storage for receiver
```

### Building

```bash
npm run build
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [Hyperdrive](https://github.com/hypercore-protocol/hyperdrive)
- [Hyperswarm](https://github.com/hyperswarm/hyperswarm)
- [Localdrive](https://github.com/hypercore-protocol/localdrive)

## Files to Share

Share these files with your teammate:
- `package.json`
- `app.js`
- `index.html`
- `.gitignore`
- `README.md`

## Troubleshooting

If you encounter any issues:
1. Make sure you have the latest version of Pear CLI
2. Try deleting the `node_modules` folder and running `npm install` again
3. Check the browser console (DevTools) for error messages 